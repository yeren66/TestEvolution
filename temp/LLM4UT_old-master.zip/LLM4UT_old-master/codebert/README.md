# CodeBERT

## Assertion Generation

## Result

| Task                             | Accuracy | BLEU-4 | CodeBLEU |
|----------------------------------|----------|--------|----------|
| Assertion Generation(NewDataSet) | 40.13    | 57.16  | 56.16    |
| Assertion Generation(OldDataSet) | 54.64    | 74.31  | 73.89    |
