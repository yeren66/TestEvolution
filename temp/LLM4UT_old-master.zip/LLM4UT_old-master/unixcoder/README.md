# UniXcoder

| Task                             | Accuracy | BLEU-4 | CodeBLEU |
|----------------------------------|----------|--------|----------|
| Assertion Generation(NewDataSet) |          |        |          |
| Assertion Generation(OldDataSet) |          |        |          |
|                                  |          |        |          |