# LLM4UT

## Model Collections

| Model Name     | Size                | XMatch                                  | Note                 |
|----------------|---------------------|-----------------------------------------|----------------------|
| CodeBERT       | 125M                | 3.2692                                  |
| CodeT5         | 60M/220M/770M       | 13.4615 / 15.3846 / 16.7308
| CodeT5+        | 220M/770M/2B/6B/16B | 17.5 / 18.4615 / / /
| GraphCodeBERT  | 125M                | 7.8846
| UniXcoder      | 125M                | 8.0769
| CodeGPT        | 124M                | 18.0769
| PLBART         | 140M/400M           | 12.8846 / 15.9615
| InCoder        | 1.3B/6.7B           | 26.1538 / 30.3846
| CodeGen        | 350M/2B/6B/16B      | 18.4615 / 21.3462 / 20.0 / 29.8077      | 16b use bfloat16
| CodeGen2       | 1B/3.7B/7B/16B      | 7.3077 / 10.1923 / 19.6154
| CodeGen2.5     | 7B                  |
| StarCoderBase  | 1B/3B/7B/15.5B      | 10.3846 / 6.1538 / 4.8077
| StarCoder      | 15.5B               |                
| StarCoder2     | 3B/7B/15B           | 5.7692 / 5.7692 / 15.5769      | 15b use bfloat16, have run again with different seed
| CodeLlama      | 7B/13B/34B/70B      | 16.9231 / 19.4231              | use bfloat16
| CodeGemma      | 2B/7B               | 4.4231 /           
| DeciCoder      | 1B                  | 12.1154            
| CodeGeex2      | 6B                  |               
| Phi-1          | 1.3B                | 18.8462
| Phi-1.5        | 1.3B                | 17.1154
| Phi-2          | 2.6B                | 18.0769
| DeepSeek-Coder | 1B/5.7B/6.7B/7B/33B | 24.6154 / 24.2308 / 25.5769 / 12.8846 /
| CodeShell      | 7B                  |                 
| SantaCoder     | 1.1B                | 

## Global Settings

All models must use the same settings to ensure consistency.

1. `learning rate`: 5e-5
2. `evaluate_metrics`: eval_loss
3. `lr_scheduler_type`: cosine
4. `early_stop_strategy`：when eval loss not decrease for two epochs
5. `warmup_ratio`: 0.02 
6. `weight_decay`: 0.0 
7. `dtype`: torch.float32 if can, otherwise use torch.bfloat16 instead.
8. `save_strategy`: epoch
9. `eval_strategy`: epoch
10. `max_grad_norm`: 1.0
11. `gradient_accumulation_steps`: 1 
12. `num_train_epoch`: For small model, it can be set to 75; For larger model, it can be set to 20 
13. `per_device_train_batch_size`: decided by GPU memory, recommend 16/8/4 etc. 
14. `per_device_eval_batch_size`: the same as per_device_train_batch_size
15. `seed`: 42

## data preprocess strategy

Training data must be preprocessed correctly.

1. Encoder-decoder Model: source 和 target 分开，target tokenize 之后作为 label_id，source tokenize 之后获取 input_ids 和 attention_mask
2. Decoder-only Model: source + target + eos_token。
3. Encoder-only Model: 

