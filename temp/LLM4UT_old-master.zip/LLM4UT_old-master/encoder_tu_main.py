import logging
import sys
import os
import json
import math
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any
import re

import torch
import torch.nn as nn
import datasets
import transformers
import matplotlib.pyplot as plt
import numpy as np
from transformers import Trainer, Seq2SeqTrainer, EarlyStoppingCallback
from transformers.trainer import PredictionOutput
from datasets import load_dataset
from functools import partial

logger = logging.getLogger(__name__)
IGNORE_INDEX = -100
# Name of the files used for checkpointing
TRAINER_STATE_NAME = "trainer_state.json"


@dataclass
class DataArguments:
    data_path: str = field(
        default=None,
        metadata={"help": "Path to the data directory"}
    )
    train_filename: str = field(
        default=None,
        metadata={"help": "Training data filename."}
    )
    eval_filename: str = field(
        default=None,
        metadata={"help": "Evaluation data filename."}
    )
    test_filename: str = field(
        default=None,
        metadata={"help": "Test data filename."}
    )
    cache_dir: str = field(
        default="./cache",
        metadata={"help": "Directory to store cached data."}
    )
    num_proc: int = field(
        default=1,
        metadata={"help": "Number of processes to use for data preprocessing."}
    )


@dataclass
class ModelArguments:
    model_name_or_path: Optional[str] = field(default=None)
    torch_dtype: torch.dtype = field(default=torch.float32)
    device_map: str = field(default="auto")


@dataclass
class TrainingArguments(transformers.Seq2SeqTrainingArguments):
    output_dir: str = field(default="./saved_models")
    optim: str = field(default="adamw_torch")
    source_max_length: int = field(
        default=512,
        metadata={"help": "The maximum input source sequence length after tokenization."}
    )
    target_max_length: int = field(
        default=128,
        metadata={"help": "The maximum input target sequence length after tokenization."}
    )
    num_train_epochs: float = field(default=75)
    per_device_train_batch_size: int = field(default=8)
    per_device_eval_batch_size: int = field(default=8)
    gradient_accumulation_steps: int = field(default=1)
    learning_rate: float = field(default=5e-5)
    lr_scheduler_type: str = field(default="cosine")
    warmup_ratio: float = field(default=0.02)
    logging_steps: int = field(default=1)
    evaluation_strategy: str = field(default="epoch")
    eval_steps: int = field(default=1000)
    save_strategy: str = field(default="epoch")
    save_steps: int = field(default=1000)
    report_to: str = field(default="none")
    metric_for_best_model: str = field(default="eval_loss")
    greater_is_better: bool = field(default=False)
    load_best_model_at_end: bool = field(default=True)
    save_total_limit: int = field(default=10)
    seed: int = field(default=42)
    early_stop_patience: int = field(
        default=2,
        metadata={"help": "Early stopping patience for early stopping"}
    )
    plot_loss: bool = field(
        default=False,
        metadata={"help": "Whether or not to save the training loss curves."},
    )
    label_names: Optional[List[str]] = field(
        default_factory=lambda: ["target_ids", "target_attention_mask", "is_pred"],
        metadata={"help": "label names in Model forward"}
    )
    save_safetensors: bool = field(
        default=False
    )


@dataclass
class GenerationArguments:
    max_new_tokens: int = field(default=128)
    max_length: int = field(default=512)
    num_beams: int = field(default=10)

    def to_dict(self) -> Dict[str, Any]:
        args = asdict(self)
        if args.get("max_new_tokens", -1) > 0:
            args.pop("max_length", None)
        else:
            args.pop("max_new_tokens", None)
        return args


class Seq2SeqModel(nn.Module):
    """
        Build Sequence-to-Sequence Model.
        see https://github.com/microsoft/CodeBERT/blob/master/CodeBERT/code2nl/model.py

        Parameters:
        * `encoder`- encoder of seq2seq model. e.g. roberta
        * `decoder`- decoder of seq2seq model. e.g. transformer
        * `config`- configuration of encoder model.
        * `beam_size`- beam size for beam search.
        * `max_length`- max length of target for beam search.
        * `sos_id`- start of symbol ids in target for beam search.
        * `eos_id`- end of symbol ids in target for beam search.
    """

    def __init__(self,
                 encoder,
                 tokenizer,
                 config,
                 decoder=None,
                 beam_size=None,
                 max_length=None,
                 sos_id=None,
                 eos_id=None):
        super(Seq2SeqModel, self).__init__()
        self.encoder = encoder
        # Using transformer Decoder
        decoder_layer = nn.TransformerDecoderLayer(d_model=config.hidden_size, nhead=config.num_attention_heads)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=6) if decoder is None else decoder
        self.config = config
        self.tokenizer = tokenizer
        self.register_buffer("bias", torch.tril(torch.ones(2048, 2048)))
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self.lsm = nn.LogSoftmax(dim=-1)
        self.tie_weights()

        self.beam_size = beam_size
        self.max_length = max_length
        self.sos_id = sos_id
        self.eos_id = eos_id

    def _tie_or_clone_weights(self, first_module, second_module):
        """ Tie or clone module weights depending on whether we are using TorchScript or not
        """
        if self.config.torchscript:
            first_module.weight = nn.Parameter(second_module.weight.clone())
        else:
            first_module.weight = second_module.weight

    def tie_weights(self):
        """ Make sure we are sharing the input and output embeddings.
            Export to TorchScript can't handle parameter sharing so we are cloning them instead.
        """
        self._tie_or_clone_weights(self.lm_head,
                                   self.encoder.embeddings.word_embeddings)

    def forward(self,
                input_ids=None,
                attention_mask=None,
                target_ids=None,
                target_attention_mask=None,
                is_pred=None):
        outputs = self.encoder(input_ids, attention_mask=attention_mask)
        encoder_output = outputs[0].permute([1, 0, 2]).contiguous()
        attn_mask = -1e4 * (1 - self.bias[:target_ids.shape[1], :target_ids.shape[1]])
        tgt_embeddings = self.encoder.embeddings(target_ids).permute([1, 0, 2]).contiguous()
        out = self.decoder(tgt_embeddings, encoder_output, tgt_mask=attn_mask,
                           memory_key_padding_mask=(1 - attention_mask).bool())
        hidden_states = torch.tanh(self.dense(out)).permute([1, 0, 2]).contiguous()
        lm_logits = self.lm_head(hidden_states)
        # Shift so that tokens < n predict n
        active_loss = target_attention_mask[..., 1:].ne(0).view(-1) == 1
        shift_logits = lm_logits[..., :-1, :].contiguous()
        shift_labels = target_ids[..., 1:].contiguous()
        # Flatten the tokens
        loss_fct = nn.CrossEntropyLoss(ignore_index=IGNORE_INDEX)
        loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1))[active_loss],
                        shift_labels.view(-1)[active_loss])

        # Predict
        preds = []
        if torch.all(is_pred).item():
            zero = torch.tensor([0], dtype=torch.long, device="cuda")
            for i in range(input_ids.shape[0]):
                context = encoder_output[:, i:i + 1]
                context_mask = attention_mask[i:i + 1, :]
                beam = Beam(self.beam_size, self.sos_id, self.eos_id)
                _input_ids = beam.get_current_state()
                context = context.repeat(1, self.beam_size, 1)
                context_mask = context_mask.repeat(self.beam_size, 1)
                for _ in range(self.max_length):
                    if beam.done():
                        break
                    attn_mask = -1e4 * (1 - self.bias[:_input_ids.shape[1], :_input_ids.shape[1]])
                    tgt_embeddings = self.encoder.embeddings(_input_ids).permute([1, 0, 2]).contiguous()
                    out = self.decoder(tgt_embeddings, context, tgt_mask=attn_mask,
                                       memory_key_padding_mask=(1 - context_mask).bool())
                    out = torch.tanh(self.dense(out))
                    hidden_states = out.permute([1, 0, 2]).contiguous()[:, -1, :]
                    out = self.lsm(self.lm_head(hidden_states)).data
                    beam.advance(out)
                    _input_ids.data.copy_(_input_ids.data.index_select(0, beam.get_current_origin()))
                    _input_ids = torch.cat((_input_ids, beam.get_current_state()), -1)
                hyp = beam.get_hyp(beam.get_final())
                pred = beam.build_target_tokens(hyp)[:self.beam_size]
                pred = [torch.cat([x.view(-1) for x in p] + [zero] * (self.max_length - len(p))).view(1, -1) for p in
                        pred]
                preds.append(torch.cat(pred, 0).unsqueeze(0))

            preds = torch.cat(preds, 0)

        return loss, preds


class Beam(object):
    def __init__(self, size, sos, eos):
        self.size = size
        self.tt = torch.cuda
        # The score for each translation on the beam.
        self.scores = self.tt.FloatTensor(size).zero_()
        # The backpointers at each time-step.
        self.prevKs = []
        # The outputs at each time-step.
        self.nextYs = [self.tt.LongTensor(size).fill_(0)]
        self.nextYs[0][0] = sos
        # Has EOS topped the beam yet.
        self._eos = eos
        self.eosTop = False
        # Time and k pair for finished.
        self.finished = []

    def get_current_state(self):
        """
        Get the outputs for the current timestep.
        :return:
        """

        batch = self.tt.LongTensor(self.nextYs[-1]).view(-1, 1)
        return batch

    def get_current_origin(self):
        """
        Get the backpointers for the current timestep.
        :return:
        """

        return self.prevKs[-1]

    def advance(self, wordLk):
        """
        Given prob over words for every last beam `wordLk` and attention
        `attnOut`: Compute and update the beam search.
        Parameters:
        * `wordLk`- probs of advancing from the last step (K x words)
        * `attnOut`- attention at the last step
        Returns: True if beam search is complete.
        """
        numWords = wordLk.size(1)

        # Sum the previous scores.
        if len(self.prevKs) > 0:
            beamLk = wordLk + self.scores.unsqueeze(1).expand_as(wordLk)

            # Don't let EOS have children.
            for i in range(self.nextYs[-1].size(0)):
                if self.nextYs[-1][i] == self._eos:
                    beamLk[i] = -1e20
        else:
            beamLk = wordLk[0]
        flatBeamLk = beamLk.view(-1)
        bestScores, bestScoresId = flatBeamLk.topk(self.size, 0, True, True)

        self.scores = bestScores

        # bestScoresId is flattened beam x word array, so calculate which
        # word and beam each score came from
        prevK = torch.div(bestScoresId, numWords, rounding_mode='floor')
        self.prevKs.append(prevK)
        self.nextYs.append((bestScoresId - prevK * numWords))

        for i in range(self.nextYs[-1].size(0)):
            if self.nextYs[-1][i] == self._eos:
                s = self.scores[i]
                self.finished.append((s, len(self.nextYs) - 1, i))

        # End condition is when top-of-beam is EOS and no global score.
        if self.nextYs[-1][0] == self._eos:
            self.eosTop = True

    def done(self):
        return self.eosTop and len(self.finished) >= self.size

    def get_final(self):
        if len(self.finished) == 0:
            self.finished.append((self.scores[0], len(self.nextYs) - 1, 0))
        self.finished.sort(key=lambda a: -a[0])
        if len(self.finished) != self.size:
            unfinished = []
            for i in range(self.nextYs[-1].size(0)):
                if self.nextYs[-1][i] != self._eos:
                    s = self.scores[i]
                    unfinished.append((s, len(self.nextYs) - 1, i))
            unfinished.sort(key=lambda a: -a[0])
            self.finished += unfinished[:self.size - len(self.finished)]
        return self.finished[:self.size]

    def get_hyp(self, beam_res):
        """
        Walk back to construct the full hypothesis.
        """
        hyps = []
        for _, timestep, k in beam_res:
            hyp = []
            for j in range(len(self.prevKs[:timestep]) - 1, -1, -1):
                hyp.append(self.nextYs[j + 1][k])
                k = self.prevKs[j][k]
            hyps.append(hyp[::-1])
        return hyps

    def build_target_tokens(self, preds):
        sentence = []
        for pred in preds:
            tokens = []
            for tok in pred:
                if tok == self._eos:
                    break
                tokens.append(tok)
            sentence.append(tokens)
        return sentence


def smooth(scalars: List[float]) -> List[float]:
    r"""
    EMA implementation according to TensorBoard.
    """
    last = scalars[0]
    smoothed = list()
    weight = 1.8 * (1 / (1 + math.exp(-0.05 * len(scalars))) - 0.5)  # a sigmoid function
    for next_val in scalars:
        smoothed_val = last * weight + (1 - weight) * next_val
        smoothed.append(smoothed_val)
        last = smoothed_val
    return smoothed


def plot_loss(save_dictionary: os.PathLike, keys: List[str] = ["loss"]) -> None:
    with open(os.path.join(save_dictionary, TRAINER_STATE_NAME), "r", encoding="utf-8") as f:
        data = json.load(f)

    for key in keys:
        steps, metrics = [], []
        for i in range(len(data["log_history"])):
            if key in data["log_history"][i]:
                steps.append(data["log_history"][i]["step"])
                metrics.append(data["log_history"][i][key])

        if len(metrics) == 0:
            logger.warning(f"No metric {key} to plot.")
            continue

        plt.figure()
        plt.plot(steps, metrics, color="#1f77b4", alpha=0.4, label="original")
        plt.plot(steps, smooth(metrics), color="#1f77b4", label="smoothed")
        plt.title("training {} of {}".format(key, save_dictionary))
        plt.xlabel("step")
        plt.ylabel(key)
        plt.legend()
        figure_path = os.path.join(save_dictionary, "training_{}.png".format(key.replace("/", "_")))
        plt.savefig(figure_path, format="png", dpi=100)
        print("Figure saved at:", figure_path)


def filter_code(codes):
    codes = codes.replace('\r',' ').replace('\n',' ').replace('\t',' ')
    codes = re.sub(' +', ' ', codes)
    return codes

def get_prompt_target(sample):
    return sample['focal_src'], sample['focal_tgt'], sample['test_src'], sample['test_tgt']


def generate_and_tokenize_prompt(sample, tokenizer, training_args, dataset_type: str = "train"):
    focal_src, focal_tgt, test_src, test_tgt = get_prompt_target(sample)
    source = [repr(focal_src)[1:-1], repr(focal_tgt)[1:-1], repr(test_src)[1:-1]]
    source_ids_list = []
    source_masks_list = []
    each_length = training_args.source_max_length // 3
    for each in source:
        ret = tokenizer(each, truncation=True, max_length=each_length,
                                padding='max_length', return_tensors='pt')
        source_ids_list.append(ret["input_ids"].squeeze(0))
        source_masks_list.append(ret["attention_mask"].squeeze(0))

    final_source_ids = torch.cat(source_ids_list)
    final_source_masks = torch.cat(source_masks_list)
    if final_source_ids.size(0) < training_args.source_max_length:
        padding_length = training_args.source_max_length - final_source_ids.size(0)
        final_source_ids = torch.cat([final_source_ids, torch.full((padding_length,),tokenizer.pad_token_id)])
        final_source_masks = torch.cat([final_source_masks, torch.zeros(padding_length)])

    # source = repr(focal_src)[1:-1] + repr(focal_tgt)[1:-1] + repr(test_src)[1:-1]
    # source = repr(test_src)[1:-1]
    target = filter_code(repr(test_tgt)[1:-1])
    # source, target = get_prompt_target(sample)
    # tokenized_source = tokenizer(source, truncation=True, max_length=training_args.source_max_length,
    #                              padding='max_length', return_tensors='pt')
    tokenized_target = tokenizer(target, truncation=True, max_length=training_args.target_max_length,
                                 padding='max_length', return_tensors='pt')
    

    # print("shape: {}".format(final_source_ids.shape))
    # print("input_ids: {}".format(final_source_ids))
    # print("attention_mask: {}".format(final_source_masks))
    # print("label: {}".format(tokenized_target["input_ids"].squeeze(0)))

    return {
        "input_ids": final_source_ids,
        "attention_mask": final_source_masks,
        "labels": tokenized_target["input_ids"].squeeze(0),
        # Custom Label Value
        # If in prediction stage, do not have label value
        "target_ids": tokenized_target["input_ids"].squeeze(0),
        "target_attention_mask": tokenized_target["attention_mask"].squeeze(0),
        "is_pred": True if dataset_type == "test" else False
    }


def get_data_module(tokenizer, training_args, data_args) -> Dict:
    data_files = {}
    if data_args.train_filename is not None:
        data_files["train"] = data_args.train_filename
    if data_args.eval_filename is not None:
        data_files["eval"] = data_args.eval_filename
    if data_args.test_filename is not None:
        data_files["test"] = data_args.test_filename

    dataset = load_dataset("json", data_dir=data_args.data_path,
                           data_files=data_files, cache_dir=None)

    result = dict()
    if data_args.train_filename is not None:
        train_dataset = dataset["train"]
        train_dataset = train_dataset.map(
            partial(generate_and_tokenize_prompt, tokenizer=tokenizer, training_args=training_args,
                    dataset_type="train"),
            num_proc=data_args.num_proc
        )
        result["train_dataset"] = train_dataset
    if data_args.eval_filename is not None:
        eval_dataset = dataset["eval"]
        eval_dataset = eval_dataset.map(
            partial(generate_and_tokenize_prompt, tokenizer=tokenizer, training_args=training_args,
                    dataset_type="eval"),
            num_proc=data_args.num_proc
        )
        result["eval_dataset"] = eval_dataset
    if data_args.test_filename is not None:
        test_dataset = dataset["test"]
        test_dataset = test_dataset.map(
            partial(generate_and_tokenize_prompt, tokenizer=tokenizer, training_args=training_args,
                    dataset_type="test"),
            num_proc=data_args.num_proc
        )
        result["test_dataset"] = test_dataset

    return result


def save_predictions(trainer: "Trainer", tokenizer, predict_results: "PredictionOutput", args) -> None:
    """
    Saves model predictions to `output_dir`.

    A custom behavior that not contained in Seq2SeqTrainer.
    """
    if not trainer.is_world_process_zero():
        return

    output_prediction_file = os.path.join(trainer.args.output_dir, "generated_predictions.jsonl")
    logger.info(f"Saving prediction results to {output_prediction_file}")

    # Handling multiple beams
    num_samples = predict_results.predictions.shape[0]
    num_beams = args.num_beams

    # Assuming that labels are the same for all beams
    labels = np.where(
        predict_results.label_ids[0] != IGNORE_INDEX, predict_results.label_ids[0], tokenizer.pad_token_id
    )
    decoded_labels = tokenizer.batch_decode(
        labels, skip_special_tokens=True, clean_up_tokenization_spaces=True
    )

    with open(output_prediction_file, "w", encoding="utf-8") as writer:
        res = []
        accs = []

        # Process each sample's predictions
        for i in range(num_samples):
            best_match = ""
            best_pred = None

            # Check each beam for the best prediction
            for beam_index in range(num_beams):
                predictions = predict_results.predictions[i, beam_index, :]
                preds = np.where(predictions != IGNORE_INDEX, predictions, tokenizer.pad_token_id)

                pad_idx = np.nonzero(preds != trainer.tokenizer.pad_token_id)[0]
                if len(pad_idx):
                    preds = np.concatenate((preds[pad_idx[0]:], preds[:pad_idx[0]]), axis=-1)  # move pad token to last

                decoded_preds = tokenizer.decode(preds, skip_special_tokens=True, clean_up_tokenization_spaces=True)

                if decoded_labels[i] == decoded_preds:
                    best_match = decoded_preds
                    break
                elif best_pred is None:
                    best_pred = decoded_preds  # Keep the first prediction as the best if none match

            # Finalize the best prediction
            if best_match:
                accs.append(1)
                res.append(json.dumps({"xmatch": True, "label": decoded_labels[i], "predict": best_match}, ensure_ascii=False))
            else:
                accs.append(0)
                res.append(json.dumps({"xmatch": False, "label": decoded_labels[i], "predict": best_pred}, ensure_ascii=False))

        # Calculate and write overall match accuracy
        xmatch = round(np.mean(accs) * 100, 4)
        logger.info(f"\nXmatch : {xmatch}")
        writer.write(f"xmatch: {xmatch}\n")
        writer.write("\n".join(res))



def main():
    parser = transformers.HfArgumentParser((ModelArguments, TrainingArguments, DataArguments, GenerationArguments))
    model_args, training_args, data_args, generation_args, _ = parser.parse_args_into_dataclasses(
        return_remaining_strings=True)

    # Setup logging
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    if training_args.should_log:
        # The default of training_args.log_level is passive, so we set log level at info here to have that default.
        transformers.utils.logging.set_verbosity_info()

    log_level = training_args.get_process_log_level()
    logger.setLevel(log_level)
    datasets.utils.logging.set_verbosity(log_level)
    transformers.utils.logging.set_verbosity(log_level)
    transformers.utils.logging.enable_default_handler()
    transformers.utils.logging.enable_explicit_format()

    # Log on each process the small summary:
    logger.warning(
        f"Process rank: {training_args.local_rank}, device: {training_args.device}, n_gpu: {training_args.n_gpu}, "
        + f"distributed training: {training_args.parallel_mode.value == 'distributed'}, 16-bits training: {training_args.fp16}"
    )
    logger.info(f"Data parameters {data_args}")
    logger.info(f"Model parameters {model_args}")
    logger.info(f"Training/evaluation parameters {training_args}")

    # build model
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        model_args.model_name_or_path,
        source_max_length=training_args.source_max_length,
        padding_side="right", # codegeex-6b is left
        use_fast=True,
        trust_remote_code=True
    )
    config = transformers.AutoConfig.from_pretrained(model_args.model_name_or_path,trust_remote_code=True)
    encoder = transformers.AutoModel.from_pretrained(
        pretrained_model_name_or_path=model_args.model_name_or_path,
        torch_dtype=model_args.torch_dtype,
        device_map=model_args.device_map,
        trust_remote_code=True
    )
    model = Seq2SeqModel(
        encoder=encoder,
        config=config,
        tokenizer=tokenizer,
        beam_size=generation_args.num_beams,
        max_length=generation_args.max_length,
        sos_id=tokenizer.cls_token_id,
        eos_id=tokenizer.sep_token_id
    )

    if training_args.predict_with_generate:
        tokenizer.padding_side = "left"  # use left-padding in generation

    data_module = get_data_module(tokenizer=tokenizer, training_args=training_args, data_args=data_args)
    trainer = Seq2SeqTrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=training_args.early_stop_patience)],
        train_dataset=data_module["train_dataset"],
        eval_dataset=data_module["eval_dataset"],
    )

    if training_args.do_train:
        train_result = trainer.train(resume_from_checkpoint=training_args.resume_from_checkpoint)
        trainer.save_model(output_dir=training_args.output_dir)
        trainer.log_metrics("train", train_result.metrics)
        trainer.save_metrics("train", train_result.metrics)
        trainer.save_state()
        if trainer.is_world_process_zero() and training_args.plot_loss:
            plot_loss(training_args.output_dir, keys=["loss", "eval_loss"])

    if training_args.do_predict:
        model.load_state_dict(torch.load(training_args.output_dir + "/pytorch_model.bin"))
        gen_kwargs = generation_args.to_dict()
        gen_kwargs["eos_token_id"] = [tokenizer.eos_token_id] + tokenizer.additional_special_tokens_ids
        gen_kwargs["pad_token_id"] = tokenizer.pad_token_id

        predict_results = trainer.predict(data_module["test_dataset"], metric_key_prefix="predict", **gen_kwargs)
        if training_args.predict_with_generate:  # predict_loss will be wrong if predict_with_generate is enabled
            predict_results.metrics.pop("predict_loss", None)
        trainer.log_metrics("predict", predict_results.metrics)
        trainer.save_metrics("predict", predict_results.metrics)
        save_predictions(trainer, tokenizer, predict_results, generation_args)


if __name__ == "__main__":
    main()
