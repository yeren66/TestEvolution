# CodeT5

## codet5-base

| Task                             | Accuracy | BLEU-4 | CodeBLEU |
|----------------------------------|----------|--------|----------|
| Assertion Generation(NewDataSet) | 46.09    | 70.92  | 70.67    |
| Assertion Generation(OldDataSet) | 60.26    | 85.12  | 87.32    |

## codet5-large

| Task                             | Accuracy | BLEU-4 | CodeBLEU |
|----------------------------------|----------|--------|----------|
| Assertion Generation(NewDataSet) |          |        |          |
| Assertion Generation(OldDataSet) |          |        |          |

## codet5-small

| Task                             | Accuracy | BLEU-4 | CodeBLEU |
|----------------------------------|----------|--------|----------|
| Assertion Generation(NewDataSet) |          |        |          |
| Assertion Generation(OldDataSet) |          |        |          |
