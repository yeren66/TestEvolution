from transformers import (
    AutoModelForCausalLM,
    AutoModelForSeq2SeqLM,
    AutoModel,
    AutoModelForMaskedLM
)

MODEL_CLASS = {
    # decoder
    "codellama": AutoModelForCausalLM,
    "codegemma": AutoModelForCausalLM,
    "codegen": AutoModelForCausalLM,
    "codegen2": AutoModelForCausalLM,
    "codegen2_5": AutoModelForCausalLM,
    "codegpt": AutoModelForCausalLM,
    "codeshell": AutoModelForCausalLM,
    "decicoder": AutoModelForCausalLM,
    "incoder": AutoModelForCausalLM,
    "phi-1": AutoModelForCausalLM,
    "starcoder": AutoModelForCausalLM,
    "starcoderbase": AutoModelForCausalLM,
    "starcoder2": AutoModelForCausalLM,
    "santacoder": AutoModelForCausalLM,
    "deepseek-coder": AutoModelForCausalLM,
    # encoder-decoder
    "codet5": AutoModelForSeq2SeqLM,
    "codet5p": AutoModelForSeq2SeqLM,
    "plbart": AutoModelForSeq2SeqLM,
    # encoder
    "codebert": AutoModel,
    "unixcoder": AutoModel,
    "codegeex2": AutoModel,
    "codegeex": AutoModel,
    "graphcodebert": AutoModel
}
