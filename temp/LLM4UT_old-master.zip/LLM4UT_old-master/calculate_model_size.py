from transformers import AutoModel

path = "/data/Models/phi/phi-2"

model = AutoModel.from_pretrained(path)

total_params = sum(p.numel() for p in model.parameters())
def readable(total_params):
    if total_params < 1_000_000:
        return f"{total_params/1_000:.1f}K"
    elif total_params < 1_000_000_000:
        return f"{total_params/1_000_000:.1f}M"
    else:
        return f"{total_params/1_000_000_000:.1f}B"

model_name = path.split('/')[-1]
print(model_name + ' size : ' + readable(total_params))
