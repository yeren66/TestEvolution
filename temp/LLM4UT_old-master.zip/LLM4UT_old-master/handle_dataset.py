import json

def remove_surrogates(s):
    return ''.join(c if not 0xD800 <= ord(c) < 0xE000 else '' for c in s)

def filter_json(file_path, output_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
    except json.JSONDecodeError as e:
        print(f"Failed to decode JSON: {e}")
        return

    keys_to_keep = {'focal_src', 'focal_tgt', 'test_src', 'test_tgt'}
    filtered_data = []
    for item in data:
        filtered_item = {key: remove_surrogates(item[key]) for key in keys_to_keep if key in item}
        filtered_data.append(filtered_item)

    try:
        # 将数据转为JSON字符串
        json_string = json.dumps(filtered_data, ensure_ascii=False, indent=4)
        with open(output_path, 'w', encoding='utf-8') as file:
            file.write(json_string)
    except UnicodeEncodeError as e:
        print(f"Unicode encoding error: {e}")

    print(f"Filtered data written to '{output_path}'.")

# 使用示例
filter_json('train.json', 'filter_train.json')
