# README

## 总览

更改后的脚本添加了两个参数，pretrained_model_name和pretrained_model_path. 前者指当前运行的模型名称，后者是存放该模型预训练权重, tokenizer以及config文件的路径。下表是模型名称和对应的huggingface模型链接

| pretrained_model_name | huggingface_path                                             | size  |
| --------------------- | ------------------------------------------------------------ | ----- |
| codebert              | [microsoft/codebert-base](https://huggingface.co/microsoft/codebert-base) | 125M  |
| codegen               | [Salesforce/codegen-350M-multi](https://huggingface.co/Salesforce/codegen-350M-multi) | 350M  |
| codet5                | [Salesforce/codet5-base](https://huggingface.co/Salesforce/codet5-base) | 220M  |
| codet5p               | [Salesforce/codet5p-770m](https://huggingface.co/Salesforce/codet5p-770m) | 770M  |
| codegpt               | [microsoft/CodeGPT-small-java-adaptedGPT2](https://huggingface.co/microsoft/CodeGPT-small-java-adaptedGPT2) | 124M  |
| graphcodebert         | [microsoft/graphcodebert-base](https://huggingface.co/microsoft/graphcodebert-base) | 125M  |
| incoder               | [facebook/incoder-6B](https://huggingface.co/facebook/incoder-6B) | 6.7B  |
| llama                 | [meta-llama](https://huggingface.co/meta-llama)              | 70B   |
| starcoder             | [bigcode/starcoder](https://huggingface.co/bigcode/starcoder) | 15.5B |
| unixcoder             | [microsoft/unixcoder-base](https://huggingface.co/microsoft/unixcoder-base) | 125M  |

## classification

首先切换到classification目录下，更改run.py文件中的参数。

需要更改的参数有：

```
--saved_model_name 为保存的训练权重的名称，一般为{pretrained_model_name}_class.bin，例如codebert_class.bin
--pretrained_model_name 为当前运行的预训练模型名称，为这个模型名称的小写，例如codebert
--pretrained_model_path 为huggingface上下载的模型预训练权重, tokenizer以及config文件的路径，建议设置为../data/model/{pretrained_model_name}
```

## updating

updating目录下有三个子目录，分别是casual, no casual, t5，分别代表三种类型的模型，要运行对应的模型，请切换到对应的目录。

casual: codegen, codegpt, incoder, llama, starcoder

no casual: codebert, graphcodebert, unixcoder

t5: codet5, codet5p

需要更改的参数有：

```
--saved_model_name 为保存的训练权重的名称，一般为{pretrained_model_name}_gen.bin，例如codebert_gen.bin
--test_data_file 为在classification步骤中生成的test文件名称，需要根据当前的预训练模型名称,../../data/results/{pretrained_model_name}/{pretrained_model_name}_test.json，例如../../data/results/codebert/codebert_test.json
--pretrained_model_name 为当前运行的预训练模型名称，为这个模型名称的小写，例如codebert
--pretrained_model_path 为huggingface上下载的模型预训练权重, tokenizer以及config文件的路径，建议设置为../../data/model/{pretrained_model_name}
```

注意相对路径！
