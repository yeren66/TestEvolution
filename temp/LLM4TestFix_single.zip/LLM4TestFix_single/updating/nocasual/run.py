import os
if __name__ =="__main__":
    os.system("python updating_main.py \
    --output_dir=../../data/results/saved_models \
    --saved_model_name=codebert_gen.bin \
    --do_train \
    --train_data_file=../../data/gen/train.json \
    --eval_data_file=../../data/gen/test.json \
    --epochs 75 \
    --encoder_block_size 128 \
    --decoder_block_size 128 \
    --train_batch_size 8 \
    --eval_batch_size 8 \
    --learning_rate 2e-5 \
    --max_grad_norm 1.0 \
    --pretrained_model_name codebert \
    --pretrained_model_path ../data/pretrained_model_path/codebert \
    --n_gpu 1 \
    --evaluate_during_training \
    --seed 123456  2>&1 | tee train.log")
    os.system("python updating_main.py \
    --output_dir=../../data/results/saved_models \
    --saved_model_name=codebert_gen.bin \
    --do_test \
    --test_data_file=../../data/results/codebert/codebert_test.json \
    --pretrained_model_name codebert \
    --pretrained_model_path ../data/pretrained_model_path/codebert \
    --beam_size 1 \
    --encoder_block_size 128 \
    --decoder_block_size 128 \
    --eval_batch_size 1 \
    --n_gpu 1")
