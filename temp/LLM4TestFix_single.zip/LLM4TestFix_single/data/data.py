import pandas as pd
import json

def readjson_all(filename):
    d = []
    with open(filename, mode='r', encoding='utf-8') as f:
        dicts = json.load(f)
    for i in dicts:
        d.append(i)
    return d

def json2csv(filename):
    data = readjson_all(filename)

    edit_seq = []
    focal_src = []
    focal_tgt = []
    test_src = []
    label = []
    for item in data:
        edit_seq.append(item['edit_seq'])
        focal_src.append(repr(item['focal_src'])[1:-1])
        focal_tgt.append(repr(item['focal_tgt'])[1:-1])
        test_src.append(repr(item['test_src'])[1:-1])
        label.append(item['label'])
    df = pd.DataFrame()
    df['edit_seq'] = edit_seq
    df['focal_src'] = focal_src
    df['focal_tgt'] = focal_tgt
    df['test_src'] = test_src
    df['label'] = label
    df.to_csv(filename.replace('.json','.csv'),index=False)
def test():
    data = readjson_all('./class/test.json')
    data_to_save = []
    tpc_id = [1,3,5]
    for i, d in enumerate(data):
        if i in tpc_id:
            data_to_save.append(d)
if __name__ == '__main__':
    # json2csv('./class/train.json')
    # json2csv('./class/test.json')
    # json2csv('./class/train_part.json')
    # json2csv('./class/test_part.json')
    #
    # json2csv('./gen/train.json')
    # json2csv('./gen/test.json')
    # json2csv('./gen/train_part.json')
    # json2csv('./gen/test_part.json')
    test()
