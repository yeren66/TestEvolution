import os
if __name__ == '__main__':
    os.system('python updating_main.py \
        --do_train \
        --do_eval \
        --train_filename ../../data/gen/train.json \
        --dev_filename ../../data/gen/test.json \
        --test_filename ../../data/results/codegen/codegen_test.json \
        --output_dir ../../data/results/saved_models \
        --max_source_length 128 \
        --max_target_length 128 \
        --beam_size 1 \
        --pretrained_model_name codegen \
        --pretrained_model_path ../data/pretrained_model_path/codegen \
        --train_batch_size 8 \
        --eval_batch_size 8 \
        --learning_rate 5e-5 \
        --num_train_epochs 30 \
        2>&1 | tee ./24-Jan-2023/train.log')
    os.system('python updating_main.py \
         --do_test \
         --model_type gpt2 \
         --model_name_or_path microsoft/CodeGPT-small-java-adaptedGPT2 \
         --test_filename ../../data/results/codegen/codegen_test.json \
         --output_dir ../../data/results/saved_models \
         --pretrained_model_name codegen \
         --pretrained_model_path ../data/pretrained_model_path/codegen \
         --max_source_length 128 \
         --max_target_length 128 \
         --beam_size 1 \
         --train_batch_size 8 \
         --eval_batch_size 8 \
         --learning_rate 5e-5 \
         --num_train_epochs 30 \
         2>&1 | tee ./24-Jan-2023/eval-23-Aug.log')