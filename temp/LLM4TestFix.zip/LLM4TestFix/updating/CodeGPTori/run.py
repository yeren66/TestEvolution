# -*- coding: utf-8 -*-
# Copyright 2018 The Google AI Language Team Authors and The HuggingFace Inc. team.
# Copyright (c) 2018, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Fine-tuning the library models for language modeling on a text file (GPT, GPT-2, BERT, RoBERTa).
GPT and GPT-2 are fine-tuned using a causal language modeling (CLM) loss while BERT and RoBERTa are fine-tuned
using a masked language modeling (MLM) loss.
"""

from __future__ import absolute_import
import os
import re
import sys
import bleu
import pickle
import torch
import json
import random
import logging
import argparse
import numpy as np
from io import open
from itertools import cycle
import torch.nn as nn
from model import Seq2Seq
from tqdm import tqdm, trange
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler, TensorDataset
from torch.utils.data.distributed import DistributedSampler
from transformers import (WEIGHTS_NAME, AdamW, get_linear_schedule_with_warmup,
                          RobertaConfig, RobertaModel, RobertaTokenizer,
                          GPT2Config, GPT2LMHeadModel, GPT2Tokenizer)

MODEL_CLASSES = {
    'roberta': (RobertaConfig, RobertaModel, RobertaTokenizer),
    'gpt2': (GPT2Config, GPT2LMHeadModel, GPT2Tokenizer),
}

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
    datefmt='%m/%d/%Y %H:%M:%S',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


def read_examples(filename):
    d = []
    with open(filename, mode='r', encoding='utf-8') as f:
        dicts = json.load(f)
    for i in dicts:
        d.append(i)
    return d


class InputFeatures(object):
    """A single training/test features for a example."""

    def __init__(self, example_id, inputs, labels):
        self.example_id = example_id
        self.inputs = inputs
        self.labels = labels
        self.attn_mask = np.array(labels) != 0
        self.loss_mask = np.array(labels) == 2


def filter_code(codes):
    codes = codes.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')
    codes = re.sub(' +', ' ', codes)
    return codes


def convert_examples_to_features(examples, tokenizer, args, stage=None):
    features = []
    for example_index, example in enumerate(tqdm(examples)):
        source_edit = example['edit_seq']
        edit_lst = []
        for i in source_edit:
            edit_lst.extend(i)
        edit_lst = edit_lst[:args.max_source_length]
        edit_lst = ' '.join(edit_lst)
        to_encode = [edit_lst, repr(example['focal_src'])[1:-1], repr(example['focal_tgt'])[1:-1],
                     repr(example['test_src'])[1:-1]]
        label = filter_code(repr(example['test_tgt'])[1:-1])
        block_size = 4 * args.max_source_length + args.max_target_length
        source = []
        for func in to_encode:
            s = tokenizer.encode(func)[:args.max_source_length]
            if len(s)>args.max_source_length:
                s = s[:args.max_source_length]
            source += s
        source = source[:4*args.max_source_length-1]
        target = tokenizer.encode(label)[:args.max_target_length-1]
        if stage == 'test':
            target = []

        if stage == 'train':
            inputs = source + [tokenizer.bos_token_id] + target + [tokenizer.eos_token_id]
            labels = [1] * len(source) + [2] * (len(target) + 1) + [0]
            assert len(inputs) <= block_size
            pad_len = block_size - len(inputs)
            inputs += [tokenizer.pad_token_id] * pad_len
            labels += [0] * pad_len
            assert len(inputs) == len(labels)
        else:
            inputs = source + [tokenizer.bos_token_id]
            labels = [1] * len(source) + [2]

        if example_index < 5:
            if stage == 'train':
                logger.info("*** Example ***")
                logger.info("idx: {}".format(example_index))

                logger.info("inputs: {}".format(' '.join(map(str, inputs))))
                logger.info("labels: {}".format(' '.join(map(str, labels))))

        features.append(
            InputFeatures(
                example_index,
                inputs,
                labels,
            )
        )
    return features


class TextDataset(Dataset):
    def __init__(self, examples, args):
        self.examples = examples
        self.args = args

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, item):
        return torch.tensor(self.examples[item].inputs), torch.tensor(self.examples[item].labels), \
               torch.tensor(self.examples[item].attn_mask, dtype=torch.uint8), \
               torch.tensor(self.examples[item].loss_mask, dtype=torch.uint8)


def set_seed(seed=42):
    random.seed(seed)
    os.environ['PYHTONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True


def eval_bleu(args, dev_dataset, model, device, tokenizer):
    # Calculate bleu
    if 'dev_bleu' in dev_dataset:
        eval_examples, eval_data = dev_dataset['dev_bleu']
    else:
        eval_examples = read_examples(args.dev_filename)
        eval_examples = random.sample(eval_examples, min(1000, len(eval_examples)))
        eval_features = convert_examples_to_features(eval_examples, tokenizer, args, stage='test')
        eval_data = TextDataset(eval_features, args)
        dev_dataset['dev_bleu'] = eval_examples, eval_data

    eval_sampler = SequentialSampler(eval_data)
    eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=1)

    model.eval()
    p = []
    for batch in tqdm(eval_dataloader, total=len(eval_dataloader)):
        batch = tuple(t.to(device) for t in batch)
        inputs, labels, attn_mask, loss_mask = batch
        with torch.no_grad():
            preds = model(inputs=inputs, labels=labels, attn_mask=attn_mask, loss_mask=loss_mask, pred=True)
            for pred in preds:
                t = pred[0].cpu().numpy()
                t = list(t)
                if 0 in t:
                    t = t[:t.index(0)]
                text = tokenizer.decode(t, clean_up_tokenization_spaces=False)
                p.append(text)
    model.train()
    predictions = []
    accs = []
    with open(os.path.join(args.output_dir, "dev.output"), 'w') as f, \
            open(os.path.join(args.output_dir, "dev.gold"), 'w') as f1:
        for ref, gold in zip(p, eval_examples):
            predictions.append(str(gold.idx) + '\t' + ref)
            f.write(str(gold.idx) + '\t' + ref + '\n')
            f1.write(str(gold.idx) + '\t' + gold.target + '\n')
            accs.append(ref == gold.target)

    (goldMap, predictionMap) = bleu.computeMaps(predictions, \
                                                os.path.join(args.output_dir, "dev.gold"))
    dev_bleu = round(bleu.bleuFromMaps(goldMap, predictionMap)[0], 2)
    xMatch = round(np.mean(accs) * 100, 4)

    return dev_bleu, xMatch


def test(args, model, tokenizer, device, epoch=0):
    file = args.test_filename
    logger.info("Test file: {}".format(file))
    eval_examples = read_examples(file)
    eval_features = convert_examples_to_features(eval_examples, tokenizer, args, stage='test')
    eval_data = TextDataset(eval_features, args)

    # Calculate bleu
    eval_sampler = SequentialSampler(eval_data)
    eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=1)

    model.eval()
    p = []
    for batch in tqdm(eval_dataloader, total=len(eval_dataloader)):
        batch = tuple(t.to(device) for t in batch)
        inputs, labels, attn_mask, loss_mask = batch
        with torch.no_grad():
            preds = model(inputs=inputs, labels=labels, attn_mask=attn_mask, loss_mask=loss_mask, pred=True)
            for pred in preds:
                beam_texts = []
                for i in range(args.beam_size):
                    t = pred[i].cpu().numpy()
                    t = list(t)
                    if 0 in t:
                        t = t[:t.index(0)]
                    text = tokenizer.decode(t, clean_up_tokenization_spaces=False)
                    oriinput = tokenizer.decode(list(inputs[0].cpu().numpy()), clean_up_tokenization_spaces=False)
                    if text.startswith(oriinput):
                        text = text[len(oriinput):]
                    beam_texts.append(text)
                p.append(beam_texts)
    model.train()
    accs = []
    for ref, gold in zip(p, eval_examples):
        flag = False
        for beam in ref:
            ori = tokenizer.decode(tokenizer.encode(filter_code(repr(gold['test_tgt'])[1:-1]))[:args.max_target_length-1])
            beam = tokenizer.decode(tokenizer.encode(filter_code(beam))[:args.max_target_length-1])
            if beam == ori:
                flag = True
                break
        accs.append(flag)
    xMatch = round(np.mean(accs) * 100, 4)
    filename = args.test_filename
    data = read_examples(filename)
    edit_seq = []
    focal_src = []
    focal_tgt = []
    test_src = []
    test_tgt = []
    for item in data:
        edit_seq.append(item['edit_seq'])
        focal_src.append(repr(item['focal_src'])[1:-1])
        focal_tgt.append(repr(item['focal_tgt'])[1:-1])
        test_src.append(repr(item['test_src'])[1:-1])
        test_tgt.append(repr(item['test_tgt'])[1:-1])
    f = open('../../data/results/codegpt/gen_res.txt', 'w', encoding='utf-8')
    for fs, ft, ts, tt, ref, a in zip(focal_src, focal_tgt, test_src, test_tgt, p, accs):
        f.write("focal_src:\n" + fs + "\n")
        f.write("focal_tgt:\n" + ft + "\n")
        f.write("test_src:\n" + ts + "\n")
        f.write("test_src:\n" + tt + "\n")
        f.write("match:\n" + str(a) + "\n")
        f.write("raw_predictions:\n")
        for i in ref:
            f.write(i + "\n")
    logger.info("   %s = %s" % ("xMatch", str(xMatch)))
    logger.info("  " + "*" * 20)


def update_config(model, tokenizer):
    model.config.bos_token_id = tokenizer.bos_token_id
    model.config.eos_token_id = tokenizer.eos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id


def main():
    parser = argparse.ArgumentParser()

    ## Required parameters  
    parser.add_argument("--model_type", default=None, type=str, required=True,
                        help="Model type: e.g. roberta")
    parser.add_argument("--model_name_or_path", default=None, type=str, required=True,
                        help="Path to pre-trained model: e.g. roberta-base")
    parser.add_argument("--output_dir", default=None, type=str, required=True,
                        help="The output directory where the model predictions and checkpoints will be written.")
    parser.add_argument("--load_model_path", default=None, type=str,
                        help="Path to trained model: Should contain the .bin files")
    ## Other parameters
    parser.add_argument("--train_filename", default=None, type=str,
                        help="The train filename. Should contain the .jsonl files for this task.")
    parser.add_argument("--dev_filename", default=None, type=str,
                        help="The dev filename. Should contain the .jsonl files for this task.")
    parser.add_argument("--test_filename", default=None, type=str,
                        help="The test filename. Should contain the .jsonl files for this task.")

    parser.add_argument("--config_name", default="", type=str,
                        help="Pretrained config name or path if not the same as model_name")
    parser.add_argument("--tokenizer_name", default="", type=str,
                        help="Pretrained tokenizer name or path if not the same as model_name")
    parser.add_argument("--max_source_length", default=64, type=int,
                        help="The maximum total source sequence length after tokenization. Sequences longer "
                             "than this will be truncated, sequences shorter will be padded.")
    parser.add_argument("--max_target_length", default=32, type=int,
                        help="The maximum total target sequence length after tokenization. Sequences longer "
                             "than this will be truncated, sequences shorter will be padded.")

    parser.add_argument("--do_train", action='store_true',
                        help="Whether to run training.")
    parser.add_argument("--do_eval", action='store_true',
                        help="Whether to run eval on the dev set.")
    parser.add_argument("--do_test", action='store_true',
                        help="Whether to run eval on the dev set.")
    parser.add_argument("--do_lower_case", action='store_true',
                        help="Set this flag if you are using an uncased model.")
    parser.add_argument("--no_cuda", action='store_true',
                        help="Avoid using CUDA when available")

    parser.add_argument("--train_batch_size", default=8, type=int,
                        help="Batch size per GPU/CPU for training.")
    parser.add_argument("--patience", default=5, type=int)
    parser.add_argument("--eval_batch_size", default=8, type=int,
                        help="Batch size per GPU/CPU for evaluation.")
    parser.add_argument('--gradient_accumulation_steps', type=int, default=1,
                        help="Number of updates steps to accumulate before performing a backward/update pass.")
    parser.add_argument("--learning_rate", default=5e-5, type=float,
                        help="The initial learning rate for Adam.")
    parser.add_argument("--beam_size", default=10, type=int,
                        help="beam size for beam search")
    parser.add_argument("--weight_decay", default=0.0, type=float,
                        help="Weight deay if we apply some.")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float,
                        help="Max gradient norm.")
    parser.add_argument("--num_train_epochs", default=3, type=int,
                        help="Total number of training epochs to perform.")
    parser.add_argument("--max_steps", default=-1, type=int,
                        help="If > 0: set total number of training steps to perform. Override num_train_epochs.")
    parser.add_argument("--eval_steps", default=-1, type=int,
                        help="")
    parser.add_argument("--train_steps", default=-1, type=int,
                        help="")
    parser.add_argument("--warmup_steps", default=0, type=int,
                        help="Linear warmup over warmup_steps.")
    parser.add_argument("--local_rank", type=int, default=-1,
                        help="For distributed training: local_rank")
    parser.add_argument('--seed', type=int, default=42,
                        help="random seed for initialization")
    # print arguments
    args = parser.parse_args()
    # make dir if output_dir not exist
    if os.path.exists(args.output_dir) is False:
        os.makedirs(args.output_dir)
    logger.info(args)

    # Setup CUDA, GPU & distributed training
    if args.local_rank == -1 or args.no_cuda:
        device = torch.device("cuda" if torch.cuda.is_available() and not args.no_cuda else "cpu")
        args.n_gpu = torch.cuda.device_count()
    else:  # Initializes the distributed backend which will take care of sychronizing nodes/GPUs
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        torch.distributed.init_process_group(backend='nccl')
        args.n_gpu = 1
    logger.warning("Process rank: %s, device: %s, n_gpu: %s, distributed training: %s",
                   args.local_rank, device, args.n_gpu, bool(args.local_rank != -1))
    args.device = device
    # Set seed
    set_seed(args.seed)

    config_class, model_class, tokenizer_class = MODEL_CLASSES[args.model_type]
    tokenizer = tokenizer_class.from_pretrained(args.model_name_or_path, do_lower_case=args.do_lower_case, \
                                                bos_token='<s>', eos_token='</s>', pad_token='<pad>',
                                                unk_token='<|UNKNOWN|>', sep_token='concode_elem_sep')
    tokenizer.add_tokens(["<S2SV_StartBug>", "<S2SV_EndBug>", "<S2SV_blank>", "<S2SV_ModStart>", "<S2SV_ModEnd>"])
    # budild model
    decoder = model_class.from_pretrained(args.model_name_or_path)
    decoder.resize_token_embeddings(len(tokenizer))
    update_config(decoder, tokenizer)
    model = Seq2Seq(decoder=decoder, config=decoder.config,
                    beam_size=args.beam_size, max_length=args.max_target_length,
                    sos_id=tokenizer.bos_token_id, eos_id=tokenizer.eos_token_id)
    if args.load_model_path is not None:
        logger.info("reload model from {}".format(args.load_model_path))
        model.load_state_dict(torch.load(args.load_model_path))

    model.to(device)
    if args.local_rank != -1:
        # Distributed training
        try:
            from apex.parallel import DistributedDataParallel as DDP
        except ImportError:
            raise ImportError(
                "Please install apex from https://www.github.com/nvidia/apex to use distributed and fp16 training.")

        model = DDP(model)
    elif args.n_gpu > 1:
        # multi-gpu training
        model = torch.nn.DataParallel(model)

    fa = open(os.path.join(args.output_dir, 'summary.log'), 'a+')

    if args.do_train:
        # Prepare training data loader
        train_examples = read_examples(args.train_filename)
        train_features = convert_examples_to_features(train_examples, tokenizer, args, stage='train')
        train_data = TextDataset(train_features, args)

        if args.local_rank == -1:
            train_sampler = RandomSampler(train_data)
        else:
            train_sampler = DistributedSampler(train_data)
        train_dataloader = DataLoader(train_data, sampler=train_sampler, \
                                      batch_size=args.train_batch_size // args.gradient_accumulation_steps)

        num_train_optimization_steps = args.train_steps

        # Prepare optimizer and schedule (linear warmup and decay)
        no_decay = ['bias', 'LayerNorm.weight']
        optimizer_grouped_parameters = [
            {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
             'weight_decay': args.weight_decay},
            {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
        ]
        t_total = len(train_dataloader) // args.gradient_accumulation_steps * args.num_train_epochs
        optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)
        scheduler = get_linear_schedule_with_warmup(optimizer,
                                                    num_warmup_steps=int(t_total * 0.1),
                                                    num_training_steps=t_total)

        # Start training
        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(train_examples))
        logger.info("  Batch size = %d", args.train_batch_size)
        logger.info("  Num epoch = %d", args.num_train_epochs)

        model.train()
        dev_dataset = {}
        not_loss_dec_cnt = 0
        nb_tr_examples, nb_tr_steps, tr_loss, global_step, best_bleu, best_loss = 0, 0, 0, 0, 0, 1e6
        for epoch in range(args.num_train_epochs):
            bar = tqdm(train_dataloader, total=len(train_dataloader))
            for batch in bar:
                batch = tuple(t.to(device) for t in batch)
                inputs, labels, attn_mask, loss_mask = batch

                loss, _, _ = model(inputs=inputs, labels=labels, attn_mask=attn_mask, loss_mask=loss_mask, pred=False)

                if args.n_gpu > 1:
                    loss = loss.mean()  # mean() to average on multi-gpu.
                if args.gradient_accumulation_steps > 1:
                    loss = loss / args.gradient_accumulation_steps
                tr_loss += loss.item()
                train_loss = round(tr_loss * args.gradient_accumulation_steps / (nb_tr_steps + 1), 4)
                bar.set_description("epoch {} loss {}".format(epoch, train_loss))
                nb_tr_examples += inputs.size(0)
                nb_tr_steps += 1
                loss.backward()

                if (nb_tr_steps + 1) % args.gradient_accumulation_steps == 0:
                    # Update parameters
                    optimizer.step()
                    optimizer.zero_grad()
                    scheduler.step()
                    global_step += 1

            if args.do_eval:
                # Eval model with dev dataset
                tr_loss = 0
                nb_tr_examples, nb_tr_steps = 0, 0
                eval_flag = False
                if 'dev_loss' in dev_dataset:
                    eval_examples, eval_data = dev_dataset['dev_loss']
                else:
                    eval_examples = read_examples(args.dev_filename)
                    eval_features = convert_examples_to_features(eval_examples, tokenizer, args, stage='train')
                    eval_data = TextDataset(eval_features, args)
                    dev_dataset['dev_loss'] = eval_examples, eval_data
                eval_sampler = SequentialSampler(eval_data)
                eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=args.eval_batch_size)

                logger.info("\n***** Running evaluation *****")
                logger.info("  Num examples = %d", len(eval_examples))
                logger.info("  Batch size = %d", args.eval_batch_size)

                # Start Evaling model
                model.eval()
                eval_loss, tokens_num = 0, 0
                for batch in eval_dataloader:
                    batch = tuple(t.to(device) for t in batch)
                    inputs, labels, attn_mask, loss_mask = batch

                    with torch.no_grad():
                        _, loss, num = model(inputs=inputs, labels=labels, \
                                             attn_mask=attn_mask, loss_mask=loss_mask, pred=False)

                    eval_loss += loss.sum().item()
                    tokens_num += num.sum().item()
                # Pring loss of dev dataset
                model.train()
                eval_loss = eval_loss / tokens_num
                result = {
                    'eval_ppl': round(np.exp(eval_loss), 5),
                    'global_step': global_step + 1,
                    'train_loss': round(train_loss, 5)
                }
                for key in sorted(result.keys()):
                    logger.info("  %s = %s", key, str(result[key]))
                logger.info("  " + "*" * 20)

                # #save last checkpoint
                # last_output_dir = os.path.join(args.output_dir, 'checkpoint-last')
                # if not os.path.exists(last_output_dir):
                #     os.makedirs(last_output_dir)
                # model_to_save = model.module if hasattr(model, 'module') else model  # Only save the model it-self
                # output_model_file = os.path.join(last_output_dir, "pytorch_model.bin")
                # torch.save(model_to_save.state_dict(), output_model_file)
                if eval_loss < best_loss:
                    logger.info("  Best ppl:%s", round(np.exp(eval_loss), 5))
                    logger.info("  " + "*" * 20)
                    fa.write("[%d] Best ppl changed into %.4f\n" % (epoch, round(np.exp(eval_loss), 5)))
                    best_loss = eval_loss
                    # Save best checkpoint for best ppl
                    output_dir = os.path.join(args.output_dir, 'checkpoint-best-loss')
                    if not os.path.exists(output_dir):
                        os.makedirs(output_dir)
                    model_to_save = model.module if hasattr(model, 'module') else model  # Only save the model it-self
                    output_model_file = os.path.join(output_dir, "gpt2_gen.bin")
                    torch.save(model_to_save.state_dict(), output_model_file)
                else:
                    not_loss_dec_cnt += 1
                    logger.info("Ppl does not decrease for %d epochs", not_loss_dec_cnt)
                    if not_loss_dec_cnt > args.patience:
                        early_stop_str = "[%d] Early stop as not_loss_dec_cnt=%d\n" % (
                            epoch, not_loss_dec_cnt)
                        logger.info(early_stop_str)
                        fa.write(early_stop_str)
                        break
                # dev_bleu, xMatch = eval_bleu(args, dev_dataset, model, device, tokenizer)
                # logger.info("  %s = %s, %s = %s"%("bleu-4",str(dev_bleu), "xMatch", str(xMatch)))
                # logger.info("  "+"*"*20)
                # if dev_bleu > best_bleu:
                #     logger.info("  Best bleu:%s",dev_bleu)
                #     logger.info("  "+"*"*20)
                #     best_bleu=dev_bleu
                #     # Save best checkpoint for best bleu
                #     output_dir = os.path.join(args.output_dir, 'checkpoint-best-bleu')
                #     if not os.path.exists(output_dir):
                #         os.makedirs(output_dir)
                #     model_to_save = model.module if hasattr(model, 'module') else model  # Only save the model it-self
                #     output_model_file = os.path.join(output_dir, "pytorch_model.bin")
                #     torch.save(model_to_save.state_dict(), output_model_file)
    if args.do_test:
        if args.do_train:
            model = model_to_save
        test(args, model, tokenizer, device, -1)


if __name__ == "__main__":
    main()
