## Training
### Raw

mkdir -p ./24-Jan-2023/
#
python run.py \
        --do_train \
        --do_eval \
        --model_type gpt2 \
        --train_filename ../../data/gen/train.json \
        --dev_filename ../../data/gen/test.json \
        --test_filename ../../data/results/starcoder/starcoder_test.json \
        --output_dir ../../data/results/saved_models \
        --max_source_length 128 \
        --max_target_length 128 \
        --beam_size 1 \
        --train_batch_size 8 \
        --eval_batch_size 8 \
        --learning_rate 5e-5 \
        --num_train_epochs 30 \
        2>&1 | tee ./24-Jan-2023/train.log

# ## Testing

python run.py \
         --do_test \
         --model_type gpt2 \
         --load_model_path ../../data/results/saved_models/checkpoint-best-loss/starcoder_gen.bin \
         --model_name_or_path microsoft/CodeGPT-small-java-adaptedGPT2 \
         --test_filename ../../data/results/starcoder/starcoder_test.json \
         --output_dir ../../data/results/saved_models \
         --max_source_length 128 \
         --max_target_length 128 \
         --beam_size 1 \
         --train_batch_size 8 \
         --eval_batch_size 8 \
         --learning_rate 5e-5 \
         --num_train_epochs 30 \
         2>&1 | tee ./24-Jan-2023/eval-23-Aug.log
