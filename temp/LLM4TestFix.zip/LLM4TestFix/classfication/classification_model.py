import torch
import torch.nn as nn
from torch.nn import CrossEntropyLoss
from transformers import RobertaForSequenceClassification, RobertaTokenizer


class RobertaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, features, **kwargs):
        x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(x)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


class CodeBertModel(RobertaForSequenceClassification):
    def __init__(self, encoder, config, tokenizer, args):
        super(CodeBertModel, self).__init__(config=config)
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = RobertaClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1),
                                               output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = \
                self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions)[0]
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)[0]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob

class CodeT5ClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, x, **kwargs):
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.out_proj(x)
        return x

class CodeT5Model(torch.nn.Module):
    def __init__(self, model,config,tokenizer,args):
        super(CodeT5Model, self).__init__()
        # bert 预训练模型
        self.codet5 = model
        self.tokenizer = tokenizer
        self.config = config
        for param in self.codet5.parameters():
            param.requires_grad = True  # 使参数可更新
        self.classifier = CodeT5ClassificationHead(config)

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        attention_mask = input_ids.ne(self.tokenizer.pad_token_id)
        if output_attentions:
            outputs = self.codet5(input_ids=input_ids, attention_mask=attention_mask,
                                  labels=input_ids, decoder_attention_mask=attention_mask, output_hidden_states=True,output_attentions=output_attentions)
            attentions = outputs.decoder_attentions
            hidden_states = outputs['encoder_last_hidden_state']
            eos_mask = input_ids.eq(self.config.eos_token_id)

            if len(torch.unique(eos_mask.sum(1))) > 1:
                print(eos_mask)
                print(input_ids)
                print(self.tokenizer.decode(input_ids))
                raise ValueError("All examples must have the same number of <eos> tokens.")
            vec = hidden_states[eos_mask, :].view(hidden_states.size(0), -1,
                                                  hidden_states.size(-1))[:, -1, :]
            logits = self.classifier(vec)
            prob = nn.functional.softmax(logits)

            if labels is not None:
                loss_fct = nn.CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob,attentions
            else:
                return prob,attentions
        else:
            outputs = self.codet5(input_ids=input_ids, attention_mask=attention_mask,
                                  labels=input_ids, decoder_attention_mask=attention_mask, output_hidden_states=False,
                                  output_attentions=output_attentions)
            hidden_states = outputs['encoder_last_hidden_state']
            eos_mask = input_ids.eq(self.config.eos_token_id)

            if len(torch.unique(eos_mask.sum(1))) > 1:
                for i in range(len(input_ids)):
                    print(eos_mask[i])
                    print(input_ids[i])
                    print(self.tokenizer.decode(input_ids[i]))

                raise ValueError("All examples must have the same number of <eos> tokens.")
            vec = hidden_states[eos_mask, :].view(hidden_states.size(0), -1,
                                                  hidden_states.size(-1))[:, -1, :]
            logits = self.classifier(vec)
            prob = nn.functional.softmax(logits)

            if labels is not None:
                loss_fct = nn.CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob

class CodeT5pModel(torch.nn.Module):
    def __init__(self, model,config,tokenizer,args):
        super(CodeT5pModel, self).__init__()
        # bert 预训练模型
        self.codet5 = model
        self.tokenizer = tokenizer
        self.config = config
        for param in self.codet5.parameters():
            param.requires_grad = True  # 使参数可更新
        self.classifier = CodeT5ClassificationHead(config)

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        attention_mask = input_ids.ne(self.tokenizer.pad_token_id)
        if output_attentions:
            outputs = self.codet5(input_ids=input_ids, attention_mask=attention_mask,
                                  labels=input_ids, decoder_attention_mask=attention_mask, output_hidden_states=True,output_attentions=output_attentions)
            attentions = outputs.decoder_attentions
            hidden_states = outputs['encoder_last_hidden_state']
            eos_mask = input_ids.eq(self.config.eos_token_id)

            if len(torch.unique(eos_mask.sum(1))) > 1:
                print(eos_mask)
                print(input_ids)
                print(self.tokenizer.decode(input_ids))
                raise ValueError("All examples must have the same number of <eos> tokens.")
            vec = hidden_states[eos_mask, :].view(hidden_states.size(0), -1,
                                                  hidden_states.size(-1))[:, -1, :]
            logits = self.classifier(vec)
            prob = nn.functional.softmax(logits)

            if labels is not None:
                loss_fct = nn.CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob,attentions
            else:
                return prob,attentions
        else:
            outputs = self.codet5(input_ids=input_ids, attention_mask=attention_mask,
                                  labels=input_ids, decoder_attention_mask=attention_mask, output_hidden_states=False,
                                  output_attentions=output_attentions)
            hidden_states = outputs['encoder_last_hidden_state']
            eos_mask = input_ids.eq(self.config.eos_token_id)

            if len(torch.unique(eos_mask.sum(1))) > 1:
                for i in range(len(input_ids)):
                    print(eos_mask[i])
                    print(input_ids[i])
                    print(self.tokenizer.decode(input_ids[i]))

                raise ValueError("All examples must have the same number of <eos> tokens.")
            vec = hidden_states[eos_mask, :].view(hidden_states.size(0), -1,
                                                  hidden_states.size(-1))[:, -1, :]
            logits = self.classifier(vec)
            prob = nn.functional.softmax(logits)

            if labels is not None:
                loss_fct = nn.CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob

class CodeGenClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, x, **kwargs):
        x = x.reshape(-1, x.size(-1))
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.out_proj(x)
        return x


class CodeGenModel(torch.nn.Module):
    def __init__(self, encoder, config, tokenizer, args):
        super(CodeGenModel, self).__init__()
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = CodeGenClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1),
                                               output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            else:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob


class CodeGPTModel(torch.nn.Module):
    def __init__(self, encoder, config, tokenizer, args):
        super(CodeGPTModel, self).__init__()
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.config = config
        self.classifier = nn.Linear(config.n_embd, 2, bias=False)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.transformer(input_ids=input_ids, attention_mask=input_ids.ne(1),
                                                   output_attentions=output_attentions)
            else:
                outputs = self.encoder.transformer(inputs_embeds=input_embed, output_attentions=output_attentions)
            hidden_states = outputs[0]
            logits = self.classifier(hidden_states)
            attention = outputs.attentions
            if input_ids is not None:
                batch_size, sequence_length = input_ids.shape[:2]
            else:
                batch_size, sequence_length = input_embed.shape[:2]
            if input_ids is not None:
                sequence_lengths = torch.ne(input_ids, self.config.pad_token_id).sum(-1) - 1
            else:
                sequence_lengths = -1
            pooled_logits = logits[torch.arange(batch_size, device=logits.device), sequence_lengths]
            prob = torch.softmax(pooled_logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(pooled_logits.view(-1, 2), labels.view(-1))
                return loss, prob, attention
            else:
                return prob, attention
        else:
            if input_ids is not None:
                outputs = self.encoder.transformer(input_ids=input_ids, attention_mask=input_ids.ne(1),
                                                   output_attentions=output_attentions)
            else:
                outputs = self.encoder.transformer(inputs_embeds=input_embed, output_attentions=output_attentions)
            hidden_states = outputs[0]
            logits = self.classifier(hidden_states)
            if input_ids is not None:
                batch_size, sequence_length = input_ids.shape[:2]
            else:
                batch_size, sequence_length = input_embed.shape[:2]
            if input_ids is not None:
                sequence_lengths = torch.ne(input_ids, self.config.pad_token_id).sum(-1) - 1
            else:
                sequence_lengths = -1
            pooled_logits = logits[torch.arange(batch_size, device=logits.device), sequence_lengths]
            prob = torch.softmax(pooled_logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(pooled_logits.view(-1, 2), labels.view(-1))
                return loss, prob
            else:
                return prob

class GraphCodeBertModel(RobertaForSequenceClassification):
    def __init__(self, encoder, config, tokenizer, args):
        super(GraphCodeBertModel, self).__init__(config=config)
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = RobertaClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1),
                                               output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = \
                self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions)[0]
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)[0]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob

class InCoderClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""
    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, x, **kwargs):
        x = x.reshape(-1, x.size(-1))
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.out_proj(x)
        return x


class InCoderModel(torch.nn.Module):
    def __init__(self, encoder, config, tokenizer, args):
        super(InCoderModel, self).__init__()
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = InCoderClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            else:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob

class LlamaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, x, **kwargs):
        x = x.reshape(-1, x.size(-1))
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.out_proj(x)
        return x


class LlamaModel(torch.nn.Module):
    def __init__(self, encoder, config, tokenizer, args):
        super(LlamaModel, self).__init__()
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = LlamaClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            else:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob

class StarCoderClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, x, **kwargs):
        x = x.reshape(-1, x.size(-1))
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.out_proj(x)
        return x


class StarCoderModel(torch.nn.Module):
    def __init__(self, encoder, config, tokenizer, args):
        super(StarCoderModel, self).__init__()
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = StarCoderClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1),
                                               output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            else:
                outputs = self.encoder(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions,
                                       output_hidden_states=True)
                outputs = outputs[
                              'hidden_states'][-1][:, 0, :]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob


class UnixCoderClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, features, **kwargs):
        x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        x = self.dropout(x)
        x = self.dense(x)
        x = torch.tanh(x)
        x = self.dropout(x)
        x = self.out_proj(x)
        return x


class UnixCoderModel(RobertaForSequenceClassification):
    def __init__(self, encoder, config, tokenizer, args):
        super(UnixCoderModel, self).__init__(config=config)
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.classifier = UnixCoderClassificationHead(config)
        self.args = args

    def forward(self, input_embed=None, labels=None, output_attentions=False, input_ids=None):
        if output_attentions:
            if input_ids is not None:
                outputs = self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1),
                                               output_attentions=output_attentions)
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)
            attentions = outputs.attentions
            last_hidden_state = outputs.last_hidden_state
            logits = self.classifier(last_hidden_state)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob, attentions
            else:
                return prob, attentions
        else:
            if input_ids is not None:
                outputs = \
                self.encoder.roberta(input_ids, attention_mask=input_ids.ne(1), output_attentions=output_attentions)[0]
            else:
                outputs = self.encoder.roberta(inputs_embeds=input_embed, output_attentions=output_attentions)[0]
            logits = self.classifier(outputs)
            prob = torch.softmax(logits, dim=-1)
            if labels is not None:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits, labels)
                return loss, prob
            else:
                return prob