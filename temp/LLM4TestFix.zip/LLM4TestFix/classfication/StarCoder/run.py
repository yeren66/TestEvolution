import os
if __name__ =="__main__":
    os.system("python starcoder_main.py \
      --output_dir=../../data/results/saved_models \
      --model_type=roberta \
      --do_train \
      --do_test \
      --train_data_file=../../data/class/train.json \
      --eval_data_file=../../data/class/test.json \
      --test_data_file=../../data/class/test.json \
      --epochs 30 \
      --block_size 128 \
      --train_batch_size 16 \
      --eval_batch_size 16 \
      --learning_rate 2e-5 \
      --max_grad_norm 1.0 \
      --evaluate_during_training \
      --model_name starcoder_class.bin \
      --n_gpu 1\
      --seed 123456  2>&1 | tee train.log")

