# README

This project is divided into two parts, namely classification and updating. In the classification stage, the model first categorizes the dataset to construct a sub-dataset. Then, in the updating stage, this sub-dataset is generated.

For each model, you only need to `cd` into the corresponding directory and directly run the `run.py` file. If you need to modify the running parameters, please directly change them in the `run.py`. The results are stored in `data/results`.

Regarding CodeLlama, it is necessary to first convert the CodeLlama model weights provided on the official website into the Hugging Face format (for specific operations, see the official website), and then place the model weights and configuration files, etc., in the `data/CodeLlama` folder.
